//icsd22172  
//Στελλα Πλυτα
//ασκηση 02

import java.util.*;
//εφαρμοζουμε την hashset & hasmap μας
//ΔΕΝ ΘΕΛΩ ΔΙΠΛΩΤΥΠΑ , ΑΡΑ ΧΑΣΣΕΤ!!!
//ΧΑΣΣΜΑΠ , ΓΙΑ ΣΥΓΚΕΚΡΙΜΕΝΗ ΤΙΜΗ ΜΟΝΑΔΙΚΟ ΚΛΕΙΔΙ
public class StringProcessor {
private HashMap<String, HashSet<Integer>> wordPositions;
private String originalText;

public StringProcessor(String text) { //εφαρμοζουμε τον κονστρακτορα μας για αρχικοποιηση
this.originalText = text;
this.wordPositions = new HashMap<>();
analyzeText();             ///κληση, την ανοιγω απο κατω
}

private void analyzeText() { //αναλυση+αποθηκευση 
//αυτο ειναι τελειο, σημαινει διαχωρισμος με βαση κενα, ένα ή περισσοτερα
String[] words = originalText.split("\\s+");//εφαρμοζουμε το split(String)!!
for (int i = 0; i < words.length; i++) {//μια μια τη λεξη
String cleanWord = words[i].toLowerCase()
.replaceAll("[,\\.!?;:]", "");//τα καθαριζει

if (!cleanWord.isEmpty()) {//ενας ελενχος
if (!wordPositions.containsKey(cleanWord)) {
wordPositions.put(cleanWord, new HashSet<>());
}
wordPositions.get(cleanWord).add(i);
}}}//καταλληγει σε αποθηκευση θεσης εκαστοτε το θεμα 

public void displayWordPositions() {
System.out.println("LEKSEIS KAI OI 8ESEIS:");
System.out.print("[");
        
boolean first = true;
for (Map.Entry<String, HashSet<Integer>> entry : wordPositions.entrySet()) {
if (!first) System.out.print(", ");
            
System.out.print(entry.getKey() + " : {");
ArrayList<Integer> sortedPositions = new ArrayList<>(entry.getValue());//ομορφη ταξινομιση, απο χασσετ τα μεταφερουμε σε λιστα οπως και στην ασκηση 1
Collections.sort(sortedPositions);
            
for (int i = 0; i < sortedPositions.size(); i++) {
if (i > 0) System.out.print(", ");
System.out.print(sortedPositions.get(i));
}
System.out.print("}");
first = false;
}
System.out.println("]");
}

public String reconstructText() { //αλλη λειτουργια για ανασυνθεση του κειμενου μας
int maxIndex = 0;
for (HashSet<Integer> positions : wordPositions.values()) {
for (int pos : positions) {
if (pos > maxIndex) {
maxIndex = pos;
}}}//μεγεθοσ = μαξθεση+1
String[] reconstructed = new String[maxIndex + 1];//ο πινακας μας
//
for (Map.Entry<String, HashSet<Integer>> entry : wordPositions.entrySet()) {
String word = entry.getKey();
for (int position : entry.getValue()) {
reconstructed[position] = word;
}} 
StringBuilder result = new StringBuilder();//εφαρμοζουμε το StringBuilder, τελειο
for (int i = 0; i < reconstructed.length; i++) {
if (reconstructed[i] != null) {
if (i > 0) result.append(" ");
result.append(reconstructed[i]);
}
}
     
return result.toString();
}
public void analyzeFrequency() { //αλλη λειτουργια! η εμφανηση, πληθος θεσεων/λεξη
HashMap<String, Integer> frequencies = new HashMap<>();
for (Map.Entry<String, HashSet<Integer>> entry : wordPositions.entrySet()) {
frequencies.put(entry.getKey(), entry.getValue().size());
}
        
int maxFreq = 0;
int minFreq = Integer.MAX_VALUE; //εμπειρικα στο μιν, βαζουμε την μεγαλυτερη τιμη
        
for (int freq : frequencies.values()) {
if (freq > maxFreq) maxFreq = freq;
if (freq < minFreq) minFreq = freq;
}
        
ArrayList<String> mostFrequent = new ArrayList<>(); //υψηλη εμφανιση
for (Map.Entry<String, Integer> entry : frequencies.entrySet()) {
if (entry.getValue() == maxFreq) {
mostFrequent.add(entry.getKey());
}
}
        //με ελαχιστη συχνοτητα δλδ εμφανηση
ArrayList<String> leastFrequent = new ArrayList<>();
for (Map.Entry<String, Integer> entry : frequencies.entrySet()) {
if (entry.getValue() == minFreq) {
leastFrequent.add(entry.getKey());
}
}
        







//αποτελεσματα




System.out.println("\nPame! analuoume suxnotita:");
System.out.println("a.. lekseis me > suxnotita (" + maxFreq + " fores):");
for (String word : mostFrequent) {
System.out.println("   " + word);
}
     
System.out.println("\nb.. lekseis me < suxnotita(" + minFreq + " fores):");
for (String word : leastFrequent) {
System.out.println("   " + word);
}}
}

