//icsd22172  
//Στελλα Πλυτα
//ασκηση 02

public class Main {
public static void main(String[] args) {
String text = "The quick brown fox jumps over the lazy dog. " +"The fox is fast, but the dog is slow.";
System.out.println("ARXIKO KEIMENO:");
System.out.println(text);
System.out.println();
//εφαρμοζουμε τον StringProcessor 
StringProcessor processor = new StringProcessor(text);
 //εφαρμοζετε η πρωτη λειτουργια μας
processor.displayWordPositions();
System.out.println();
 //η αλλη λειτουργια
String reconstructed = processor.reconstructText();
System.out.println("NEO KEIMENO");
System.out.println(reconstructed);        
//η αλλη λειτουργια!
processor.analyzeFrequency();
}}
