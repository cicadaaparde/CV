//icsd22172  
//Στελλα Πλυτα
//ασκηση 03
package lab_atomiki_03;



public class Scoooter{
private String scooterId;
private int batteryLevel;      
private ScoooterStatus status;
public Scoooter(String scooterId, int batteryLevel) {
this.scooterId = scooterId;
this.batteryLevel = batteryLevel;
this.status = ScoooterStatus.AVAILABLE;} 

public String getScooterId() {
return scooterId;
}
public int getBatteryLevel() {
return batteryLevel;
}
public ScoooterStatus getStatus() {
return status;
}
    
public void setStatus(ScoooterStatus status) {
this.status = status;
}
@Override
public String toString() {
return "Scooter ID: " + scooterId + ", Battery: " + batteryLevel +"%, Status: " + status;
}
}

 

