//icsd22172  
//Στελλα Πλυτα
//ασκηση 03
package lab_atomiki_03;

public class User {
private String userId;
private String fullName;
private String email;
private Scoooter rentedScooter; 



public User(String userId, String fullName, String email) {
this.userId = userId;
this.fullName = fullName;
this.email = email;
this.rentedScooter = null;
}
public String getUserId() {
return userId;
}
  
public String getFullName() {
return fullName;
}
public String getEmail() {
return email;
}
public Scoooter getRentedScooter() {
return rentedScooter;
}
    
 
 public void setRentedScooter(Scoooter scooter) {
 this.rentedScooter = scooter;
 }
    
 public boolean hasRentedScooter() {
 return rentedScooter != null;
 }
    
 @Override
 public String toString() {
 return "User ID: " + userId + ", Name: " + fullName + ", Email: " + email;
}
}

