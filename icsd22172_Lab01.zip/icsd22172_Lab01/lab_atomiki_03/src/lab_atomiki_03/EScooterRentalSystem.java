//icsd22172  
//Στελλα Πλυτα
//ασκηση 03
package lab_atomiki_03;
import java.util.ArrayList;
import java.util.HashMap;
//εφαρμοζουμε πολλους ελενχους! υπαρχει σκουτερ(?) εχει νοικιασει ήδη(?), ειναι διαθεσιμο(?), ειναι >40%φορτισμενο(?)
public class EScooterRentalSystem {
private HashMap<String, Station> stations;  
private HashMap<String, Scoooter> scoooters;  
private HashMap<String, User> users; 

public EScooterRentalSystem() {
stations = new HashMap<>();
scoooters = new HashMap<>();
users = new HashMap<>();
}
 public boolean addStation(String name, String address, int capacity) {
 
 if (stations.containsKey(name)) {
 System.out.println("ERROR tipota " + name + " YPARXEI IDI");
 return false;
 }
 if (capacity <= 0) {
 System.out.println("ERROR 8elei 8etiko ari8mo ");
 return false;
 }
 
 stations.put(name, new Station(name, address, capacity));
 System.out.println("O/H" + name + " PROSTEUIKE EPITYXWS");
 return true;
 }
 public boolean addScooter(String scooterId, int batteryLevel, String stationName) {
 
 if (scoooters.containsKey(scooterId)) {
 System.out.println("ERROR to scooter" + scooterId + " YPARXEI IDI");
 return false;
 }
 
 if (!stations.containsKey(stationName)) {
 System.out.println("ERROR" + stationName + " DEN YPARXEI");
 return false;
 }
      
 Station station = stations.get(stationName);
 
 if (station.getCurrentScooterCount() >= station.getCapacity()) {
 System.out.println("ERROR" + stationName + " EXEI KSEPERASI TIN XWRITIKOTITA");
 return false;
 }
 
 Scoooter scooter = new Scoooter(scooterId, batteryLevel);
 scoooters.put(scooterId, scooter);
 station.addScooter(scooter);
 System.out.println("to scooter" + scooterId + " PROSTE8IKE EPITIXWS" + stationName + "!");
 return true;
 }   

 
 
 
 public boolean registerUser(String userId, String fullName, String email) {
 if (users.containsKey(userId)) {
 System.out.println("ERROR o xristis" + userId + " YPARXEI IDI");
 return false;
 }
        
 users.put(userId, new User(userId, fullName, email));
 System.out.println("O xristis" + fullName + " SUBSCRIBED EPITIXWS");
 return true;
 }
public boolean startRental(String userId, String scooterId) {

if (!users.containsKey(userId)) {
System.out.println("ERROR o xristis " + userId + " DEN YPARXEI");
return false;
}
if (!scoooters.containsKey(scooterId)) {
System.out.println("ERROR to scooter" + scooterId + " DEN YPARXEI");
return false;
}
        
User user = users.get(userId);
Scoooter scooter = scoooters.get(scooterId);
       

if (user.hasRentedScooter()) {
System.out.println("ERROR o xristis exei idi noikiasei scooter");
return false;
}

if (scooter.getStatus() != ScoooterStatus.AVAILABLE) {
System.out.println("ERROR TO SCOOTER DEN EINAI DIA8ESIMO");
return false;
}

if (scooter.getBatteryLevel() < 40) {
System.out.println("ERROR to scooter den einai fortismeno arketa(< 40%)!");
return false;
}
        

scooter.setStatus(ScoooterStatus.RENTED);
user.setRentedScooter(scooter);
System.out.println("to scooter " + scooterId + " noikiastike epitixws" + userId + "!");
return true;
}
    
public boolean endRental(String userId, String stationName) {
if (!users.containsKey(userId)) {
System.out.println("ERROR o xristis" + userId + " DEN YPARXEI");
return false;
}
if (!stations.containsKey(stationName)) {
System.out.println("ERROR" + stationName + " DEN YPARXEI");
return false;
}
      
User user = users.get(userId);
if (!user.hasRentedScooter()) {
System.out.println("ERROR  o xristis den exei noikiasei");
return false;
}
        
Station station = stations.get(stationName);
if (station.getCurrentScooterCount() >= station.getCapacity()) {
System.out.println("ERROR " + stationName + " EINAI OLOKLIROMENOS");
return false;
}
        

Scoooter scooter = user.getRentedScooter();
scooter.setStatus(ScoooterStatus.AVAILABLE);
station.addScooter(scooter);
user.setRentedScooter(null);
System.out.println("to scooter epistrafike epituxws" + stationName + "!");
return true;
}

public void displayAvailableScooters(String stationName) {
if (!stations.containsKey(stationName)) {
System.out.println("O" + stationName + " DEN YPARXEI");
return;
}
       
Station station = stations.get(stationName);
ArrayList<Scoooter> available = station.getAvailableScooters();
       
if (available.isEmpty()) {
System.out.println("DEN YPARXOYN DIA8ESIMA SCOOTER STON" + stationName);
} else {
System.out.println("DIA8ESIMA SCOOTER STON" + stationName + ":");
for (Scoooter scooter : available) {
System.out.println("  " + scooter);
}
}
}
    

public void displayUserScooter(String userId) {
if (!users.containsKey(userId)) {
System.out.println("O xristis " + userId + " DEN YPARXEI");
return;
}
      
User user = users.get(userId);
if (!user.hasRentedScooter()) {
System.out.println("O xristis  " + userId + " den exei noikiasei scooter");
} else {
System.out.println("to scooter toy xristi" + userId + ":");
System.out.println("  " + user.getRentedScooter());
}
}
    

public void displayTotalScooters() {
System.out.println("Synolikos ari8mos scooter sto system" + scoooters.size());
}
   

public void displayRentedScooters() {
int count = 0;
for (Scoooter scooter : scoooters.values()) {
if (scooter.getStatus() == ScoooterStatus.RENTED) {
count++;
}
}
System.out.println("ENOIKIASMENA SCOOTER SYNOLO: " + count);
}
    

public void displayStationWithMostScooters() {
if (stations.isEmpty()) {
System.out.println("DEN YPARXXEI KATI STO SYSTIMA, ENAS STA8MOS RE PAIDI MOU");
return;
}
      
Station maxStation = null;
int maxAvailable = -1;
       
for (Station station : stations.values()) {
int available = station.getAvailableScooterCount();
if (available > maxAvailable) {
maxAvailable = available;
maxStation = station;
}
}
        
System.out.println("TA PERISSOTERA DIA8ESIMA SCOOTER");
System.out.println(maxStation + " (AVAILABLE: " + maxAvailable + ")");
}
}
