//icsd22172  
//Στελλα Πλυτα
//ασκηση 03
package lab_atomiki_03;
public enum ScoooterStatus {
AVAILABLE,  
RENTED      
}
//ENUM ΓΙΑΤΙ ΘΕΛΩ ΜΟΝΟ 2 ΚΑΤΑΣΤΑΣΕΙΣ, ΔΕΝ ΘΕΛΩ ΛΑΘΗ, ΚΑΜΙΑ ΤΥΧΑΙΑ ΤΙΜΗ!