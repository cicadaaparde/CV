//icsd22172  
//Στελλα Πλυτα
//ασκηση 03
package lab_atomiki_03;
import java.util.ArrayList;


public class Station {
private String name;
private String address;
private int capacity;                      //max
private ArrayList<Scoooter> scooters;       //scooter sta8mou
    
public Station(String name, String address, int capacity) {
this.name = name;
this.address = address;
this.capacity = capacity;
this.scooters = new ArrayList<>();
}
    
public String getName() {
return name;
}
public String getAddress() {
return address;
}
public int getCapacity() {
return capacity;
}

public int getCurrentScooterCount() {
return scooters.size();
}
public boolean addScooter(Scoooter scooter) {
if (scooters.size() < capacity) {
scooters.add(scooter);
return true;
}
return false;
}

public boolean removeScooter(Scoooter scooter) {
return scooters.remove(scooter);
}
    
 
public ArrayList<Scoooter> getAvailableScooters() {
ArrayList<Scoooter> available = new ArrayList<>();
for (Scoooter scooter : scooters) {
if (scooter.getStatus() == ScoooterStatus.AVAILABLE) {
available.add(scooter);
}
}
return available;
}
    
public int getAvailableScooterCount() {
return getAvailableScooters().size();
}
    
@Override
public String toString() {
return "Station: " + name + ", Address: " + address + ", Capacity: " + capacity + ", Current: " + scooters.size();
}
}

