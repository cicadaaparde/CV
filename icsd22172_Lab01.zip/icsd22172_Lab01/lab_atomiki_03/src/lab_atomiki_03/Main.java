//icsd22172  
//Στελλα Πλυτα
//ασκηση 03
package lab_atomiki_03;

public class Main {
public static void main(String[] args) {
EScooterRentalSystem system = new EScooterRentalSystem();
//ΠΧ   3 ΣΤΑΘΜΟΥΣ     5 ΣΚΟΥΤΕΡ     2 ΧΡΗΣΤΕΣ  
System.out.println("PROS8IKI STA8MON");
system.addStation("Central", "Syntagma", 10);
system.addStation("Pantepistimio", "Akadimias 30", 8);
system.addStation("Monastiraki", "Platia Monastiraki", 5);
        
System.out.println("\nADD SCOOTER");
system.addScooter("SC001", 85, "Central");
system.addScooter("SC002", 60, "Central");
system.addScooter("SC003", 95, "Central");
system.addScooter("SC004", 30, "Pantepistimio");//<40%
system.addScooter("SC005", 75, "Pantepistimio");
        
System.out.println("\nSUBSCRIPTION");
system.registerUser("U001", "GEO PAP", "george@example.com");
system.registerUser("U002", "MARIA 8EO", "maria@example.com");
        
System.out.println("\nSTATISTICS, ARXIKA");
system.displayTotalScooters();
system.displayRentedScooters();
        
System.out.println("\nAVAILABLE SCOOTERAKIA");
system.displayAvailableScooters("Central");
        
System.out.println("\nRENTS");
system.startRental("U001", "SC001");
system.startRental("U002", "SC002");
        
System.out.println("\nELENXOS XRISTWN");
system.displayUserScooter("U001");
system.displayUserScooter("U002");
        
System.out.println("\nSTATISTICS META TA RENTS");
system.displayRentedScooters();
system.displayStationWithMostScooters();
       
System.out.println("\nEPISTROFI SCOOTER");
system.endRental("U001", "Monastiraki");
    
System.out.println("\nFIN STATISTICS");
system.displayRentedScooters();
system.displayStationWithMostScooters();
}
}