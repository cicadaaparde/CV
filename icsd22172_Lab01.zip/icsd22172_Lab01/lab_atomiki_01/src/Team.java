//icsd22172  
//Στελλα Πλυτα
//ασκηση 01

public class Team {
    private String name;
    private String institution;
    private String country;
    private int speedScore;       
    private int accuracyScore;    
    private int innovationScore;  
    
 //εφαρμοζουμε τον κονστρακτορ μας
public Team(String name, String institution, String country, 
int speedScore, int accuracyScore, int innovationScore) {
this.name = name;
this.institution = institution;
this.country = country;
this.speedScore = speedScore;
this.accuracyScore = accuracyScore;
this.innovationScore = innovationScore;
}
    
//εφαρμοζουμε την ενθυλακωση μας
public double getAverageScore() {
return (speedScore + accuracyScore + innovationScore) / 3.0;
}
    
 
public String getCountry() {
return country;
}
    
public String getName() {
return name;
}
  
public int getSpeedScore() {
return speedScore;
}
  
public int getAccuracyScore() {
return accuracyScore;
}
    
public int getInnovationScore() {
return innovationScore;
}
    

@Override
public String toString() {
return name+ " " + country + " " + speedScore+ " " +accuracyScore + " " + innovationScore;
}
}