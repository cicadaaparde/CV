//icsd22172  
//Στελλα Πλυτα
//ασκηση 01

public class Main {
public static void main(String[] args) {
RoboCompete competition = new RoboCompete();
competition.displayResults();
}
}
