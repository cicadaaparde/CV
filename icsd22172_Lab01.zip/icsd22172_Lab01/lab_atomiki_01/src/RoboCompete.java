//32102022172  
//Στελλα Πλυτα
//ασκηση 01
import java.util.ArrayList;




import java.util.Collections;
import java.util.HashSet;
import java.util.Random;

public class RoboCompete { //ολες οι λειτουργιες στη μια κλαση που κραταει τις ομαδες
private ArrayList<Team> teams;
private static final int TOTAL_TEAMS = 60; //λιστα για τις 60 ομαδες μας

public RoboCompete() { //εφαρμοζουμε τον κονστρακτορ μας
teams = new ArrayList<>();
generateTeams(); 
}
private void generateTeams() {//βαζω ετοιμες τιμουλες απτο γοογλ
Random rand = new Random();
String[] countries = {"ALBANIA", "IRELAND", "NIGERIA", "ITALI", "GREECE","CANADA", "NETHERLANDS", "BULGARIA", "INDIA", "TURKEY"};
String[] institutions = {" Kapodistrian University of Athens", "Aristotle University of Thessaloniki","University of Patras", "University of Crete", "Harokopio University"};      

for (int i = 0; i < TOTAL_TEAMS; i++) {//φτιαχνουμε τις ομαδες μας
String teamName = "Team_" + (i + 1);
String country = countries[rand.nextInt(countries.length)];
String institution = institutions[rand.nextInt(institutions.length)];
int speed = rand.nextInt(10) + 1;
int accuracy = rand.nextInt(10) + 1;//1-10 οι βαθμοι μας
int innovation = rand.nextInt(10) + 1;
            
teams.add(new Team(teamName, institution, country, speed, accuracy, innovation));
}}

//θελω να υπολογισουμε το γενικο μεσο ορο μας
//καθε++++μεση βαθμολογια / 60
public double calculateGeneralAverage() {
double sum = 0;
for (Team team : teams) { // Enhanced for - από το εργαστήριο
sum += team.getAverageScore();
}
return sum / TOTAL_TEAMS;
}

public Team findClosestToAverage() {//εφαρμοζουμε μεση βαθμ - γενικο μεσο ορο
double generalAverage = calculateGeneralAverage();
Team closest = teams.get(0);
double minDifference = Math.abs(closest.getAverageScore() - generalAverage);
      
for (Team team : teams) {
double difference = Math.abs(team.getAverageScore() - generalAverage);
if (difference < minDifference) {
minDifference = difference;
closest = team;
}
}
return closest; //βρηκαμε την μικροτερη διαφορα μας
}
//στην προκριση 
public ArrayList<Team> getQualifiedTeams() {
double generalAverage = calculateGeneralAverage();
double threshold = (4.0 / 5.0) * generalAverage; 
ArrayList<Team> qualified = new ArrayList<>();
        
for (Team team : teams) {
if (team.getAverageScore() > threshold) {
qualified.add(team);
}
}//ο,τι ειναι μεση>οριο, φιλτρο
return qualified;
}

public void displayQualifiedCountries(boolean ascending) {
ArrayList<Team> qualified = getQualifiedTeams();
HashSet<String> countriesSet = new HashSet<>();

for (Team team : qualified) { //μοναδικεσ χωρες, χασσετ
countriesSet.add(team.getCountry());
}
ArrayList<String> countriesList = new ArrayList<>(countriesSet);
Collections.sort(countriesList);//λιστα για τη ταξινομιση μας
//    < αυξουσα
if (!ascending) {
Collections.reverse(countriesList); //   >
}
        
System.out.println("\nXwres pou prokri8ikan (taxinomimena " + 
                          (ascending ? "<" : ">") + "):");
for (String country : countriesList) {
System.out.println(country);
}
}
public void displayResults() {

double generalAverage = calculateGeneralAverage();
System.out.println("Genikos mesos oros: " + String.format("%.2f", generalAverage));
        
Team closest = findClosestToAverage();
System.out.println("\nPio konta sto meso oro exoyme thn omada:");
System.out.println(closest.getName() + " me mesi va8mologia: " + 
String.format("%.2f", closest.getAverageScore()));

displayQualifiedCountries(true); //   >
        

ArrayList<Team> qualified = getQualifiedTeams();
System.out.println("\nProkrisi Omades: " + qualified.size());
System.out.println("\nStoixeia :");
for (Team team : qualified) {
System.out.println(team); //αυτοματο toString()
}

}}
   




