<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'connect_sql.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'secretary') {
 echo "Δεν έχετε πρόσβαση.";
   exit;
}

// Αν secretary αλλάξει status
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $new_status = $_POST['status'] ?? '';
   $appointment_id = $_POST['appointment_id'] ?? 0;

  if ($new_status && $appointment_id) {
       $stmt = $conn->prepare("UPDATE appointments SET status=? WHERE id=?");
     $stmt->bind_param("si", $new_status, $appointment_id);
       $stmt->execute();
        echo "<p>Η κατάσταση ενημερώθηκε επιτυχώς.</p>";

}

//Φέρνουμε όλα τα ραντεβού
$sql = "SELECT a.id, a.appointment_date, a.start_time, a.status, u.full_name AS customer, c.model 
     FROM appointments a
   JOIN users u ON a.customer_id=u.id
      JOIN cars c ON a.car_id=c.id
   ORDER BY a.appointment_date DESC";
$result = $conn->query($sql);
?>

<h2>Γραμματεία</h2>
<table border="1" cellpadding="5">
  <tr>
    <th>ID</th>
    <th>Ημερομηνία</th>
   <th>Ώρα</th>
      <th>Πελάτης</th>
      <th>Αυτοκίνητο</th>
     <th>Κατάσταση</th>
        <th>Ενέργειες</th>
 </tr>
  <?php while ($row = $result->fetch_assoc()): ?>
   <tr>
   <td><?php echo $row['id']; ?></td>
     <td><?php echo $row['appointment_date']; ?></td>
    <td><?php echo $row['start_time']; ?></td>
    <td><?php echo htmlspecialchars($row['customer']); ?></td>
     <td><?php echo htmlspecialchars($row['model']); ?></td>
      <td><?php echo htmlspecialchars($row['status']); ?></td>
          <td>
             <form method="post" style="display:inline;">
          <input type="hidden" name="appointment_id" value="<?php echo $row['id']; ?>">
      <!--       <select name="status">
            <option value="created">Δημιουργημένο</option>
              <option value="in_progress">Σε εξέλιξη</option>
         <option value="completed">Περαιωμένο</option>
         <option value="cancelled">Ακυρωμένο</option>
          </select>
          <button type="submit">Αποθήκευση</button> -->
    </form>
      <a href="view_appointment.php?id=<?php echo $row['id']; ?>">Διαχείρηση</a>
      </td>
        </tr>
    <?php endwhile; ?>
</table>
