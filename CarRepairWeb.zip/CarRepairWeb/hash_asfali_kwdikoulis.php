<?php
echo password_hash("kapoteeipa67", PASSWORD_DEFAULT);
?>
