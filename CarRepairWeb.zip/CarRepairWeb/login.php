<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css_style_carerepeare.css">
</head>
<body>
  <div class="container">

 <div class="top-links" aria-label="Κύριοι σύνδεσμοι">
    <a href="servises.php">ΥΠΗΡΕΣΙΕΣ</a> 
    |
    <a href="register.php">ΕΓΓΡΑΦΗ</a> 
   |
   <a href="login.php">ΣΥΝΔΕΣΗ</a> 
     |
      <a href="contact.php">ΕΠΙΚΟΙΝΩΝΙΑ</a>
    </div>
    <div class="brand">
      <div class="logo">CR</div>
      <h2> CaRepair Εργαστήριο Αυτοκινήτων</h2>
    </div>

   


  <div class="container">
       <h2>Σύνδεση</h2>
   <form method="post">
            <div class="form-group">
       <label for="username">Όνομα χρήστη/Email:</label>
       <input type="text" id="username" name="username" required>
            </div>
        <div class="form-group">
            <label for="password">Κωδικός:</label>
            <input type="password" id="password" name="password" required>
          </div>
        <button type="submit">Σύνδεση</button>
            <?php 
               if (isset($login_error)) {
                    echo "<div class='error'>".$login_error."</div>";
      }
         ?>
     </form>
    </div>


<!--Το session αφορα στο file log in και ο κωδικος ο ελεγχος του χρηστη παει στον connect. Με το που γινει η συνδεση τοτε στελνουμε στον dashboard-->
<?php
session_start();
include 'connect_sql.php';
//υπαρχει εγγραφη;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the username and password from the form
   $username = $_POST['username'];
 $password = $_POST['password'];

//λειτουργια για αναζητηση χρηστη
    $sql = "SELECT id, username, password_hash, role FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    //υπαρχει χρηστης;
   if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
     // Verify the password
      if (password_verify($password, $row['password_hash'])) {
          $_SESSION['user_id'] = $row['id'];
        $_SESSION['username'] = $row['username'];
           $_SESSION['role'] = $row['role'];
         header("Location: dashboard.php");
            exit();
        } else {
       //passwordsερρορ
          $login_error = "Λάθος κωδικός!";
        }
    } else {
            $login_error = "Δεν βρέθηκε χρήστης με αυτό το όνομα χρήστη!";
    }
    if (isset($login_error)) {
        echo "<div class='error'>".$login_error."</div>";
    }
}
?>
