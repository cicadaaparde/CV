<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="css_style_carerepeare.css">
</head>
<body>
  <div class="container">
    <div class="top-links" aria-label="Κύριοι σύνδεσμοι">
  <a href="servises.php">ΥΠΗΡΕΣΙΕΣ</a> 
     |
  <a href="register.php">ΕΓΓΡΑΦΗ</a> 
     |
  <a href="login.php">ΣΥΝΔΕΣΗ</a> 
     |
    <a href="contact.php">ΕΠΙΚΟΙΝΩΝΙΑ</a>
    </div>
    <div class="brand">
      <div class="logo">CR</div>
      <h2> CaRepair Εργαστήριο Αυτοκινήτων</h2>
    </div>



    <div class="container">
   <h2>Επικοινωνία</h2>

Καλέστε: 2104223232323 |
Facebook: CaRepair