
<!DOCTYPE html>
<html lang="el">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css_style_carerepeare.css">
</head>
<body>


    <div class="top-links" aria-label="Κύριοι σύνδεσμοι">
  <a href="servises.php">ΥΠΗΡΕΣΙΕΣ</a> 
   |
    <a href="register.php">ΕΓΓΡΑΦΗ</a> 
     |
   <a href="login.php">ΣΥΝΔΕΣΗ</a> 
  |
      <a href="contact.php">ΕΠΙΚΟΙΝΩΝΙΑ</a>
    </div>
    <div class="brand">
   <div class="logo">CR</div>
      <h2> CaRepair Εργαστήριο Αυτοκινήτων</h2>
    </div>
   <div class="container">
      <!--  <?php include 'top_navigation.php'; ?>, δεν το συμπτηξα ποτέ-->
        <h2>Dashboard</h2>
<a href="PDFsheet.php" class="btn">Εξαγωγή σε PDF</a>
        </div>
</body>
</html>

<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$userRole = $_SESSION['role']; 
switch ($userRole) {
  case 'customer':
   include 'custoumer_dasboard.php';
     break;
 case 'mechanic':
    include 'mechanic_dasboard.php';
      break;
  case 'secretary':
     include 'secretery_dasboard.php';
     break;
    default:
        echo "Μη έγκυρος ρόλος χρήστη.";
    break;
}




?>
 <p>Καλωσήρθατε, <?php if(isset($_SESSION['username'])&& !empty ($_SESSION['username'])){echo $_SESSION['username'];} ?></p>

</div>
</body>

</html>