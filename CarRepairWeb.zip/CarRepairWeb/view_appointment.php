<?php
session_start();
require 'connect_sql.php';

if (!isset($_SESSION['user_id'])) {
 header('Location: login.php');
    exit;
}

$id = $_GET['id'] ?? 0;
$sql = "SELECT a.*, c.model, u.full_name AS customer_name, m.full_name AS mechanic_name
    FROM appointments a
   JOIN cars c ON a.car_id=c.id
 JOIN users u ON a.customer_id=u.id
   LEFT JOIN users m ON a.mechanic_id=m.id
        WHERE a.id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$appointment = $stmt->get_result()->fetch_assoc();
if (!$appointment) {
    echo "Δεν βρέθηκε ραντεβού.";
    exit;
}
// --- Αν secretary αλλάζει status ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update']) && $_SESSION['role'] == 'secretary') {
  $new_status = $_POST['status'] ?? '';
 $stmt = $conn->prepare("UPDATE appointments SET status=? WHERE id=?");
  $stmt->bind_param("si", $new_status, $id);
   $stmt->execute();
    $appointment['status'] = $new_status;
   echo "<p>Η κατάσταση ενημερώθηκε.</p>";
}
// --- Αν πελάτης διαγράφει το δικό του ραντεβού ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete']) && $_SESSION['user_id'] == $appointment['customer_id']) {
  $stmt = $conn->prepare("DELETE FROM appointments WHERE id=? AND customer_id=?");
  $stmt->bind_param("ii", $id, $_SESSION['user_id']);
  $stmt->execute();
   header("Location: dashboard.php");
  exit;
}
?>

<h2>Ραντεβού #<?php echo $appointment['id']; ?></h2>
<p>Ημερομηνία: <?php echo $appointment['appointment_date']; ?> <?php echo $appointment['start_time']; ?></p>
<p>Κατάσταση: <?php echo htmlspecialchars($appointment['status']); ?></p>
<p>Πελάτης: <?php echo htmlspecialchars($appointment['customer_name']); ?></p>
<p>Αυτοκίνητο: <?php echo htmlspecialchars($appointment['model']); ?></p>
<p>Μηχανικός: <?php echo $appointment['mechanic_name'] ? htmlspecialchars($appointment['mechanic_name']) : 'Δεν έχει ανατεθεί'; ?></p>
<p>Περιγραφή: <?php echo htmlspecialchars($appointment['problem_description']); ?></p>

<?php if ($_SESSION['role'] == 'secretary'): ?>
    <!-- Μόνο η γραμματεία αλλάζει κατάσταση -->
 <h3>Ανάθεση Μηχανικού</h3>
    <form method="post" action="assign_mechanic.php">
    <input type="hidden" name="appointment_id" value="<?php echo $appointment['id']; ?>">
    <select name="mechanic_id" required>
      <option value="">-- Επιλέξτε Μηχανικό --</option>
        <?php
   $mechs = $conn->query("SELECT id, full_name FROM users WHERE role='mechanic'");
     while ($m = $mechs->fetch_assoc()) {
                $selected = ($appointment['mechanic_id'] == $m['id']) ? 'selected' : '';
                echo "<option value='{$m['id']}' $selected>{$m['full_name']}</option>";
            }
           ?>
        </select>
        <button type="submit">Ανάθεση</button> </form>
    <form method="post">
        <label>Αλλαγή Κατάστασης:
        <select name="status">
   <option value="created" <?php if($appointment['status']=='created') echo 'selected'; ?>>Δημιουργημένο</option>
   <option value="in_progress" <?php if($appointment['status']=='in_progress') echo 'selected'; ?>>Σε εξέλιξη</option>
         <option value="completed" <?php if($appointment['status']=='completed') echo 'selected'; ?>>Περαιωμένο</option>
       <option value="cancelled" <?php if($appointment['status']=='cancelled') echo 'selected'; ?>>Ακυρωμένο</option>
        </select></label>
        <button type="submit" name="update">Αποθήκευση</button>
    </form>
<?php endif; ?>

<?php if ($_SESSION['user_id'] == $appointment['customer_id'] || $_SESSION['role'] == 'secretary'): ?>    <!-- Μόνο ο πελάτης && γραμματεια που το δημιούργησε μπορεί να το διαγράψει -->
    <form method="post" onsubmit="return confirm('Σίγουρα θέλετε να διαγράψετε το ραντεβού;');">
        <input type="hidden" name="delete" value="1">
        <button type="submit">Διαγραφή</button>
    </form>
<?php endif; ?>

<a href="dashboard.php">Πίσω</a>
