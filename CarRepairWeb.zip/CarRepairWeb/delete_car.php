<?php
session_start();
require 'connect_sql.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    // Αν δεν υπάρχει id, redirect
    header('Location: cars.php');
    exit;
}

$car_id = intval($_GET['id']);
$owner_id = $_SESSION['user_id'];

// Έλεγχος ότι το αυτοκίνητο ανήκει στον χρήστη
$sql_check = "SELECT id FROM cars WHERE id = ? AND owner_id = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("ii", $car_id, $owner_id);
$stmt_check->execute();
$result = $stmt_check->get_result();

if ($result->num_rows === 0) {
    // Αν δε βρεθεί ή δε ανήκει στον χρήστη
    $stmt_check->close();
    header('Location: cars.php');
    exit;
}
$stmt_check->close();
//Διαγραφή
$sql_delete = "DELETE FROM cars WHERE id = ? AND owner_id = ?";
$stmt_delete = $conn->prepare($sql_delete);
$stmt_delete->bind_param("ii", $car_id, $owner_id);
if ($stmt_delete->execute()) {
  //Επιτυχία
 $stmt_delete->close();
 $conn->close();
 header('Location: cars.php');
 exit;
} else {
    $stmt_delete->close();
    $conn->close();
    echo "Παρουσιάστηκε σφάλμα κατά τη διαγραφή.";
}
?>
