<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require 'connect_sql.php';

$customerId = $_SESSION['user_id'] ;
$sql = "SELECT id, serial_number, model, engine_type, production_date  FROM cars WHERE owner_id = ? ORDER BY id DESC";
if ($stmt = $conn->prepare($sql)) {
   $stmt->bind_param("i", $customerId);
  $stmt->execute();
    $res = $stmt->get_result();
 if ($res->num_rows === 0) {
     echo "<p>Δεν έχετε καταχωρημένα αυτοκίνητα.</p>";
    } else {
      echo "<table class='table-cars'><tr><th>#</th><th>Serial</th><th>Model</th><th>Engine Type</th><th>Έτος</th><th>Ενέργειες</th></tr>";
   while ($row = $res->fetch_assoc()) {
     $year = $row['production_date'] ? date('Y', strtotime($row['production_date'])) : '';
          echo "<tr>";
      echo "<td>" . htmlspecialchars($row['id']) . "</td>";
    echo "<td>" . htmlspecialchars($row['serial_number']) . "</td>";
    echo "<td>" . htmlspecialchars($row['model']) . "</td>";
        echo "<td>" . htmlspecialchars($row['engine_type']) . "</td>";
      echo "<td>" . htmlspecialchars($year) . "</td>";
       echo "<td><a href='delete_car.php?id=" . urlencode($row['id']) . "' onclick=\"return confirm('Διαγραφή;');\">Διαγραφή</a></td>";
           echo "</tr>";
     }
    echo "</table>";
    }
   $stmt->close();
} else {
   echo "<p>Σφάλμα φόρτωσης αυτοκινήτων.</p>";
}
?>
<a href="addcar.php">Προσθήκη νέου αυτοκινήτου</a>
