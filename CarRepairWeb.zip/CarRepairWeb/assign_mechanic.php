<?php
session_start();
require 'connect_sql.php';
if ($_SESSION['role'] != 'secretary') {
    die("Δεν έχετε πρόσβαση.");
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
 $appointment_id = intval($_POST['appointment_id']);
   $mechanic_id = intval($_POST['mechanic_id']);

 $sql = "UPDATE appointments SET mechanic_id=? WHERE id=?";
    $stmt = $conn->prepare($sql);
   $stmt->bind_param("ii", $mechanic_id, $appointment_id);

 if ($stmt->execute()) {
   header("Location: view_appointment.php?id=$appointment_id");
      exit;
    } else {
     echo "Σφάλμα: " . $conn->error;
    }
}
?>