<?php
session_start();
include 'connect_sql.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$customerId = $_SESSION['user_id'];
$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $car_id = $_POST['car_id'] ?? 0;
   $appointment_date = $_POST['appointment_date'] ?? '';
 $start_time = $_POST['start_time'] ?? '';
  $reason = $_POST['reason'] ?? '';
   $problem_description = $_POST['problem_description'] ?? '';
    $service_ids = $_POST['services'] ?? [];

   //Validation
  if (!$car_id || !$appointment_date || !$start_time) {
   $errors[] = "Παρακαλώ συμπληρώστε όλα τα πεδία.";
    }

   if (empty($errors)) {
        $conn->begin_transaction();
      try {
        $sql = "INSERT INTO appointments (appointment_date, start_time, reason, problem_description, created_at, status, car_id, customer_id, mechanic_id, total_cost)
      VALUES (?, ?, ?, ?, NOW(), 'created', ?, ?, NULL, 0)";
         $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssii", $appointment_date, $start_time, $reason, $problem_description, $car_id, $customerId);
           if (!$stmt->execute()) {
              throw new Exception("Σφάλμα: " . $conn->error);
           }

           $appointment_id = $stmt->insert_id;
            $total_cost = 0;
           if (!empty($service_ids)) {
                foreach ($service_ids as $service_id) {
                    $sql = "SELECT cost FROM services WHERE id = ?";
                  $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $service_id);
              $stmt->execute();
                 $result = $stmt->get_result();
                    $service = $result->fetch_assoc();
                 $sql = "INSERT INTO appointment_services (appointment_id, service_id, service_cost)
                            VALUES (?, ?, ?)";
                $stmt = $conn->prepare($sql);
                    $stmt->bind_param("iid", $appointment_id, $service_id, $service['cost']);
                  $stmt->execute();

                    $total_cost += $service['cost'];
                }
            }
          // Update total_cost in appointments
        $sql = "UPDATE appointments SET total_cost = ? WHERE id = ?";
           $stmt = $conn->prepare($sql);
        $stmt->bind_param("di", $total_cost, $appointment_id);
            $stmt->execute();

         $conn->commit();
           $success = "Το ραντεβού δημιουργήθηκε επιτυχώς.";
      } catch (Exception $e) {
            $conn->rollback();
          $errors[] = "Σφάλμα κατά την αποθήκευση: " . $e->getMessage();
        }
    }
}

// Φόρτωση αυτοκινήτων
$sql = "SELECT id, model FROM cars WHERE owner_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $customerId);
$stmt->execute();
$cars = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Φόρτωση υπηρεσιών
$sql = "SELECT id, description, cost FROM services";
$result = $conn->query($sql);
$services = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css_style_carerepeare.css">
</head>
<body>
  <div class="container">

    <div class="top-links" aria-label="Κύριοι σύνδεσμοι">
   <a href="servises.php">ΥΠΗΡΕΣΙΕΣ</a> 
     |
  <a href="register.php">ΕΓΓΡΑΦΗ</a> 
     |
  <a href="login.php">ΣΥΝΔΕΣΗ</a> 
     |
      <a href="contact.php">ΕΠΙΚΟΙΝΩΝΙΑ</a>
    </div>

    <div class="brand">
    <div class="logo">CR</div>
    <h2> CaRepair Εργαστήριο Αυτοκινήτων</h2>
    </div>
<div class="container">

    <h2>Δημιουργία Νέου Ραντεβού</h2>
   <?php if (!empty($errors)): ?>
        <div class="errors">
         <ul>
                <?php foreach ($errors as $error): ?>
        <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
       </div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="success">
       <p><?php echo htmlspecialchars($success); ?></p>
        </div>
    <?php endif; ?>

  <form method="post" action="">
    <label for="car_id">Αυτοκίνητο:</label>
<select name="car_id" id="car_id" required>
    <option value="">-- Επιλέξτε --</option>
    <?php foreach ($cars as $car): ?>
     <option value="<?php echo $car['id']; ?>">
    <?php echo htmlspecialchars($car['model']); ?>
        </option>
    <?php endforeach; ?>
</select>
        <br>
     <label for="appointment_date">Ημερομηνία:</label>
    <input type="date" name="appointment_date" id="appointment_date" required value="<?php echo htmlspecialchars($_POST['appointment_date'] ?? ''); ?>">
        <br>
     <label for="start_time">Ώρα Έναρξης:</label>
        <input type="time" name="start_time" id="start_time" required value="<?php echo htmlspecialchars($_POST['start_time'] ?? ''); ?>">
        <br>

       

     <label for="problem_description">Περιγραφή Προβλήματος:</label>
        <textarea name="problem_description" id="problem_description"><?php echo htmlspecialchars($_POST['problem_description'] ?? ''); ?></textarea>
      <br>

        <fieldset>
            <legend>Υπηρεσίες (επιλέξτε μία ή περισσότερες):</legend>
        <?php foreach ($services as $service): ?>
           <label>
            <input type="checkbox" name="services[]" value="<?php echo htmlspecialchars($service['id']); ?>"
         <?php echo (isset($_POST['services']) && in_array($service['id'], $_POST['services'])) ? 'checked' : ''; ?>>
             <?php echo htmlspecialchars($service['description'] . ' (' . number_format($service['cost'], 2) . '€)'); ?>
                </label><br>
          <?php endforeach; ?>
        </fieldset>

        <button type="submit">Δημιουργία Ραντεβού</button>
    </form>
   
</div>
<p><a href="dashboard.php">Επιστροφή στο dashboard</a></p>
</body>
</html>
