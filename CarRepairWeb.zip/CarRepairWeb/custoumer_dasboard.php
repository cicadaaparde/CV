<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css_style_carerepeare.css">

</head>
<body>
  

   


  <div class="container">
       

  <h2>Τα αυτοκίνητά μου:</h2>
    <?php include 'cars.php'; ?> 


  <h2>Τα ραντεβού μου:</h2>

   <?php
   // Φόρτωση ραντεβού για τον χρήστη
     $sql = "SELECT a.id, a.appointment_date, a.start_time, a.problem_description, a.status, c.model 
               FROM appointments a
           JOIN cars c ON a.car_id = c.id
       WHERE a.customer_id = ?
         ORDER BY a.appointment_date DESC";

      $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $_SESSION['user_id']);
      $stmt->execute();
       $result = $stmt->get_result();

      if ($result->num_rows > 0): ?>
        <table border="1" class="table-appointments">
                <tr>
            <th>Ημερομηνία</th>
                 <th>Ώρα</th>
                <th>Αυτοκίνητο</th>
          <th>Περιγραφή</th>
              <th>Κατάσταση</th>
        </tr>
                <?php while($row = $result->fetch_assoc()): ?>
               <tr>
                <td><?php echo htmlspecialchars($row['appointment_date']); ?></td>
                     <td><?php echo htmlspecialchars($row['start_time']); ?></td>
            <td><?php echo htmlspecialchars($row['model']); ?></td>
                        <td><?php echo htmlspecialchars($row['problem_description']); ?></td>
                 <td><?php echo htmlspecialchars($row['status']); ?>
 <td>
 <a href="view_appointment.php?id=<?php echo urlencode($row['id']); ?>" 
                   onclick="return confirm('Διαγραφή ραντεβού;');">Δες Αναλυτικά</a>  
</td>
       </tr>
       <?php endwhile; ?>
        </table>
       <?php else: ?>
        <p>Δεν έχετε κλείσει ακόμη ραντεβού.</p>
      <?php endif; ?>

      <!--  <h2>Δημιουργία Νέου Ραντεβού</h2>  -->
        <?php include 'appointments.php'; ?>
    </div>
</body>
</html>

