<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require 'connect_sql.php';

if($_SESSION['role']!='mechanic'){echo "Δεν έχετε πρόσβαση";exit;}

$mech_id=$_SESSION['user_id'];
//var_dump($mech_id, $_SESSION['role']);
$sql="SELECT a.id,a.appointment_date,a.start_time,a.status,c.model,u.full_name AS customer
 FROM appointments a
   JOIN cars c ON a.car_id=c.id
    JOIN users u ON a.customer_id=u.id
  WHERE a.mechanic_id=?";
$stmt=$conn->prepare($sql);
$stmt->bind_param("i",$mech_id);
$stmt->execute();
if ($stmt->error) {
    die("SQL Error: " . $stmt->error);
}
$res=$stmt->get_result();
echo "<h2>Τα ραντεβού μου</h2><table border=1>";
while($row=$res->fetch_assoc()){
 echo "<tr><td>{$row['appointment_date']} {$row['start_time']}</td>
  <td>{$row['customer']}</td><td>{$row['model']}</td>
  <td>{$row['status']}</td>
    <td><a href='view_appointment.php?id={$row['id']}'>Λεπτομέρειες</a></td></tr>";
}
echo "</table>";
?>
