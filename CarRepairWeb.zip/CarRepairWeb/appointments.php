<?php
if (session_status() == PHP_SESSION_NONE) {
 session_start();
}
require 'connect_sql.php';
//λέγξτε αν ο χρήστης είναι συνδεδεμένος
if (!isset($_SESSION['user_id'])) {
 header('Location: login.php');
   exit;
}


//Αποθήκευσηνέου ραντεβού
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $date = $_POST['date'];
 $time = $_POST['time'];
  $service_id = $_POST['service'];
   $car_id = $_POST['car'];
  $problem_description = $_POST['problem_description'] ?? '';
 $customer_id = $_SESSION['user_id'];

    //Δημιουργία νέου ραντεβού
  $sql = "INSERT INTO appointments (appointment_date, start_time, car_id, customer_id, problem_description, status) 
    VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$status = 'created';
$stmt->bind_param("ssiiss", $date, $time, $car_id, $customer_id, $problem_description, $status);
    
    if ($stmt->execute()) {
       $appointment_id = $stmt->insert_id;
     // Προσθήκη υπηρεσίας στο ραντεβού
      $sql2 = "INSERT INTO appointment_services (appointment_id, service_id) VALUES (?, ?)";
       $stmt2 = $conn->prepare($sql2);
       $stmt2->bind_param("ii", $appointment_id, $service_id);
      $stmt2->execute();

     echo "Νέο ραντεβού δημιουργήθηκε με επιτυχία!";
  } else {
      echo "Σφάλμα: " . $conn->error;
    }
header("Location: dashboard.php?msg=appointment_created");
    exit;
}
?>
<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css_style_carerepeare.css">
  <title>Δημιουργία Ραντεβού</title>
</head>
<body>
 <div class="container">
      <h2>Δημιουργία Νέου Ραντεβού</h2>
      <form action="appointments.php" method="post">
    <label for="date">Ημερομηνία:</label>
        <input type="date" id="date" name="date" required>
         <br>

     <label for="time">Ώρα:</label>
        <input type="time" id="time" name="time" required>
     <br>

 

    

    <label for="problem_description">Περιγραφή Προβλήματος:</label>
     <textarea name="problem_description" id="problem_description"><?php echo htmlspecialchars($_POST['problem_description'] ?? ''); ?></textarea>
      <br>


    <label for="service">Υπηρεσία:</label>
   <select id="service" name="service" required>
             <option value="">--</option>
           <?php
             $result = $conn->query("SELECT id, description FROM services");
        while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['id']}'>{$row['description']}</option>";
           }
             ?>
            </select>
        <br>

        <label for="car">Αυτοκίνητο:</label>
            <select id="car" name="car" required>
             <option value="">--</option>
           <?php
             $owner_id= $_SESSION['user_id'];
        $result = $conn->query("SELECT id,  serial_number, model FROM cars WHERE owner_id = '$owner_id'");
           while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['id']}'> {$row['serial_number']} -{$row['model']}</option>";
         }
      ?>
          </select>
         <br>
           <button type="submit">Δημιουργία Ραντεβού</button>
    </form>

<a href="dashboard.php" class="btn">Πίσω</a>
    </div>
<!-- <a href="dashboard.php" class="btn">Πίσω</a> -->

</body>
</html>
