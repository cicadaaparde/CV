<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css_style_carerepeare.css">

</head>
<body>
  <div class="container">

    <div class="top-links" aria-label="Κύριοι σύνδεσμοι">
      <a href="servises.php">ΥΠΗΡΕΣΙΕΣ</a> 
     |
      <a href="register.php">ΕΓΓΡΑΦΗ</a> 
     |
      <a href="login.php">ΣΥΝΔΕΣΗ</a> 
     |
      <a href="contact.php">ΕΠΙΚΟΙΝΩΝΙΑ</a>
    </div>

    <div class="brand">
      <div class="logo">CR</div>
      <h2> CaRepair Εργαστήριο Αυτοκινήτων</h2>
    </div>

   


    <div class="container">
        <h2>Εγγραφή</h2>
      <form id="registrationForm" method="post" action="register.php" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="username">Όνομα χρήστη:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Κωδικός:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
               
        <label for="fullname">Πλήρες Όνομα:</label>
        <input type="text" id="fullname" name="fullname" required>
    

            </div>
            <div class="form-group">
                <label for="role">Ρόλος:</label>
                <select id="role" name="role" onchange="toggleFields()">

                    <option value="null">--</option>
                    
<option value="customer">Πελάτης</option>
                    <option value="mechanic">Μηχανικός</option>
                </select>
            </div>
            <div class="form-group" id="afmField">
                <label for="afm">ΑΦΜ:</label>
                <input type="text" id="afm" name="afm">
    <label for="address">Διεύθυνση:</label>
    <input type="text" id="address" name="address">



    <label for="phone">Τηλέφωνο:</label>
    <input type="text" id="phone" name="phone">
            </div>
            <div class="form-group" id="specialtyField">
                <label for="specialty">Ειδικότητα:</label>
                <input type="text" id="specialty" name="specialty">
            </div>

            <button type="submit">Εγγραφή</button>
        </form>
    </div>

    <script>
        // Απόκρυψη πεδίων ΑΦΜ και Ειδικότητας κατά την αρχική φόρτωση
        document.getElementById('afmField').style.display = 'none';
        document.getElementById('specialtyField').style.display = 'none';

        function toggleFields() {
            var role = document.getElementById('role').value;
            if (role === 'customer') {
                document.getElementById('afmField').style.display = 'block';
                document.getElementById('specialtyField').style.display = 'none';
            } else if (role === 'mechanic') {
                document.getElementById('afmField').style.display = 'none';
                document.getElementById('specialtyField').style.display = 'block';
            } else {
                document.getElementById('afmField').style.display = 'none';
                document.getElementById('specialtyField').style.display = 'none';
            }
        }

        function validateForm() {
            // Πρόσθεσε εδώ ελέγχους εγκυρότητας για τα πεδία (π.χ. format email, ισχυρό κωδικό)
            return true; // Επιστρέφει true αν η φόρμα είναι έγκυρη, false αν όχι
        }
    </script>

</body>
</html>


<?php

include 'connect_sql.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Παίρνουμε τα δεδομένα από τη φόρμα
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
  $fullname = $_POST["fullname"];

    $role = $_POST["role"];
if($role === "null") $role = null; //ftiaxnei to sfalma
   $afm = isset($_POST["afm"]) ? $_POST["afm"] : null;
    $address = isset($_POST["address"]) ? $_POST["address"] : null;
    $phone = isset($_POST["phone"]) ? $_POST["phone"] : null;
    $specialty = isset($_POST["specialty"]) ? $_POST["specialty"] : null;  
  
  // **ΣΗΜΑΝΤΙΚΟ: Κρυπτογράφηση του κωδικού**
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Δημιουργία του SQL query
  $sql = "INSERT INTO users (username, email, password_hash, full_name, role)
        VALUES ('$username', '$email', '$password_hash', '$fullname', '$role')";


    if ($conn->query($sql) === TRUE) {
        // Η εισαγωγή έγινε με επιτυχία
        $user_id = $conn->insert_id; // Παίρνουμε το ID του χρήστη που μόλις δημιουργήθηκε



$_SESSION['user_id'] = $user_id;
$_SESSION['username'] = $username;
$_SESSION['role'] = $role;

  // Ανάλογα με τον ρόλο, αποθηκεύουμε και τα επιπλέον στοιχεία
        if ($role == 'customer') {
     $sql_customer = "INSERT INTO customer_profiles (user_id, afm, address, phone) VALUES ('$user_id', '$afm', '$address', '$phone')";
     if ($conn->query($sql_customer) === TRUE) {
                echo "Επιτυχής εγγραφή πελάτη!";
      } else {
      echo "Σφάλμα κατά την εγγραφή πελάτη: " . $conn->error;
      }

      } elseif ($role == 'mechanic') {
            $sql_mechanic = "INSERT INTO mechanic_profiles (user_id, specialty, phone) VALUES ('$user_id', '$specialty', '$phone')";
        if ($conn->query($sql_mechanic) === TRUE) {
              echo "Επιτυχής εγγραφή μηχανικού!";
         } else {
              echo "Σφάλμα κατά την εγγραφή μηχανικού: " . $conn->error;
           }
     } else {
            echo "Επιτυχής εγγραφή χρήστη!";
       }
    } else {
        echo "Σφάλμα κατά την εγγραφή χρήστη: " . $conn->error;
    }

    $conn->close();
}
?>



