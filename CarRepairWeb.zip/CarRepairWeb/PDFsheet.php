<?php
require __DIR__ . '/fpdf/fpdf.php';
include 'connect_sql.php';
session_start();
$customer_id = $_SESSION['user_id'];

//Φέρε ραντεβού
$sql = "SELECT a.id, a.date, a.status, c.make, c.model
   FROM appointments a
  JOIN cars c ON a.car_id = c.id
       WHERE a.customer_id = $customer_id";
$result = $conn->query($sql);
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'Τα ραντεβού μου', 0, 1, 'C');
$pdf->Ln(5);

//Πίνακας
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(30, 10, 'ID', 1);
$pdf->Cell(40, 10, 'Ημερομηνία', 1);
$pdf->Cell(40, 10, 'Κατάσταση', 1);
$pdf->Cell(40, 10, 'Αμάξι', 1);
$pdf->Ln();

$pdf->SetFont('Arial', '', 12);
while ($row = $result->fetch_assoc()) {
    $pdf->Cell(30, 10, $row['id'], 1);
    $pdf->Cell(40, 10, $row['date'], 1);
    $pdf->Cell(40, 10, $row['status'], 1);
    $pdf->Cell(40, 10, $row['make'] . ' ' . $row['model'], 1);
    $pdf->Ln();
}

$pdf->Output();
?>
