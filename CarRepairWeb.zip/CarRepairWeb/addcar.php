<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require 'connect_sql.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$owner_id = $_SESSION['user_id'];

//Ανέχει ήδη αυτοκίνητα, τα φορτώνουμε
$cars_result = $conn->query("SELECT id, serial_number, model, engine_type, production_date FROM cars WHERE owner_id = '$owner_id'");

// Αν υπάρχειPOST προσθέτουμε νέο υτοκίνητο
if ($_SERVER['REQUEST_METHOD'] === 'POST') {    $serial_number = trim($_POST['serial_number'] ?? '');  $model = trim($_POST['model'] ?? '');
  $engine_type = trim($_POST['engine_type'] ?? '');
  $production_date = trim($_POST['production_date'] ?? '');
  if ($model === '' || $serial_number === '') {
        $errors[] = 'Παρακαλώ συμπληρώστε!!!';
    } else {
        $sql = "INSERT INTO cars (serial_number, model, engine_type, production_date, owner_id) VALUES (?, ?, ?, ?, ?)";
     $stmt = $conn->prepare($sql);
   $stmt->bind_param("ssssi", $serial_number, $model, $engine_type, $production_date, $owner_id);
   if ($stmt->execute()) {
      echo "Το αυτοκίνητο καταχωρήθηκε.";
        // Κατα την επιτυχίαRefresh page για να το δει ο χρήστης
         header('Location: addcar.php');
       exit;
    } else {
        echo "Σφάλμα: " . $conn->error;
        }
     $stmt->close();
 }
}
?>

<!DOCTYPE html>
<html lang="el">
<head>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="css_style_carerepeare.css">
</head>
<body>
<div class="container">
    <div class="top-links" aria-label="Κύριοι σύνδεσμοι">
   <a href="servises.php">ΥΠΗΡΕΣΙΕΣ</a> 
  |
   <a href="register.php">ΕΓΓΡΑΦΗ</a> 
   |
    <a href="login.php">ΣΥΝΔΕΣΗ</a> 
    |
  <a href="contact.php">ΕΠΙΚΟΙΝΩΝΙΑ</a>
   </div>

   <div class="brand">
   <div class="logo">CR</div>
   <h2> CaRepair Εργαστήριο Αυτοκινήτων</h2>
    </div>

   
    <div class="container">
     <h2>Προσθήκη Αυτοκινήτου</h2>
<form method="POST" action="">
  <!-- <label for="auto_model">Μοντέλο αυτοκινήτου:</label>
   <input type="text" id="auto_model" name="model" placeholder="π.χ. Fiat Panda" required>
<input type="text" id="auto_serial" name="serial_number" placeholder="Serial Number" required>

   <br><br>
  <button type="submit">Πρόσθεσε αυτοκίνητο</button>-->
 <label for="serial_number">Serial Number:</label>
   <input type="text" id="serial_number" name="serial_number" required>
   <br><br>
  <label for="model">Μοντέλο αυτοκινήτου:</label>
    <input type="text" id="model" name="model" placeholder="π.χ. Fiat Panda" required>
   <br><br>
   <label for="engine_type">Τύπος κινητήρα:</label>
   <input type="text" id="engine_type" name="engine_type" required>
    <br><br>
  <label for="production_date">Ημερομηνία παραγωγής:</label>
   <input type="date" id="production_date" name="production_date" required>
   <br><br>
    <button type="submit">Πρόσθεσε αυτοκίνητο</button>


</form>
<a href="dashboard.php" class="btn">Πίσω στο Dashboard</a>
</body>
</html>
