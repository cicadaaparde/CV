//������ ����� icsd22172
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TITLE 100
#define MAX_ARTIST 100
#define HISTORY_SIZE 15
typedef struct {
int id;
char title[MAX_TITLE];
char artist[MAX_ARTIST];
int duration;
int playCount;
} Song;


typedef struct Node {
Song song;
struct Node* next;
struct Node* prev;
} Node;


typedef struct {
Node* head;
Node* tail;
Node* current;
Node* lastPlayed;
int size;
int shuffleMode; //0 off, 1 on
} Playlist;

//������ ��� ��������
typedef struct {
Song songs[HISTORY_SIZE];
int top;
} HistoryStack;

//����������� ��������

Playlist* createPlaylist() {
Playlist* plist = (Playlist*)malloc(sizeof(Playlist));
if (!plist) return NULL;

plist->head =NULL;
plist->tail= NULL;
plist->current=NULL;
plist->lastPlayed=NULL;
plist->size=0;
plist->shuffleMode=0;

return plist;
}

void addSong(Playlist* plist, Song song) {
Node* newNode = (Node*)malloc(sizeof(Node));
if (!newNode) {
printf("ME M O  RY  ERROR\n");
return;
    }

newNode->song = song;
newNode->next = NULL;
newNode->prev = NULL;

if (plist->head == NULL) {
plist->head = newNode;
plist->tail = newNode;
plist->current = newNode;
} else
{
plist->tail->next = newNode;
newNode->prev = plist->tail;
plist->tail = newNode;
    }

plist->size++;
printf("+ ADD ED: %s - %s\n", song.title, song.artist);
}

void addAt(Playlist* plist, Song song, int position) {
if (position < 1 || position > plist->size + 1) {
printf("W R ONG  S P O T  BUD\n");
return;
    }

if (position == plist->size + 1) {
addSong(plist, song);
return;
    }

Node* newNode = (Node*)malloc(sizeof(Node));
if (!newNode) {
printf("ERRO R\n");
return;
    }

newNode->song = song;

if (position == 1) {
newNode->next = plist->head;
newNode->prev = NULL;
if (plist->head != NULL) {
plist->head->prev = newNode;
  }
plist->head = newNode;
 }


 else
    {
Node* temp = plist->head;
for (int i = 1; i < position - 1; i++) {
temp = temp->next;
 }

newNode->next = temp->next;
newNode->prev = temp;


 if (temp->next != NULL) {
 temp->next->prev = newNode;
        }
temp->next = newNode;
    }

plist->size++;


printf("ADD ED  AT  %d: %s - %s\n", position, song.title, song.artist);
}

void removeAt(Playlist* plist, int position) {
if (plist->head == NULL) {
printf("EM PTY\n");
return;
}

if (position < 1 || position > plist->size) {
printf("WRO N G  PLACE\n");
return;
}

Node* temp = plist->head;

for (int i = 1; i < position; i++) {
temp = temp->next;
}

if (temp == plist->current) {
plist->current = temp->next ? temp->next : temp->prev;
}
if (temp->prev != NULL) {
temp->prev->next = temp->next;
}
 else {
plist->head = temp->next;
}

if (temp->next != NULL) {
temp->next->prev = temp->prev;
} else
 {
plist->tail = temp->prev;
}
printf("- REM OV ED: %s - %s\n", temp->song.title, temp->song.artist);
free(temp);
plist->size--;
}


//���������� ����������
void pushHistory(HistoryStack* hs, Song song);

void play(Playlist* plist, HistoryStack* hs) {
if (plist->current == NULL) {
printf("ZER O  S ON GS\n");
return;
}

//������� �� ������ �� ������� ������������
if (plist->current != plist->lastPlayed) {
plist->current->song.playCount++;
pushHistory(hs, plist->current->song);
plist->lastPlayed = plist->current;
}

printf("\n>> N O W PL AYI NG: %s - %s [%d:%02d]\n",
plist->current->song.title,
plist->current->song.artist,
plist->current->song.duration / 60,
plist->current->song.duration % 60);
printf("   REPEATS: %d\n\n", plist->current->song.playCount);
}

void nextSong(Playlist* plist) {
if (plist->current == NULL) {
printf("NO CU R REN T S ON  G\n");
return;
}

if (plist->current->next == NULL) {
printf("FIN  PLAY L I ST \n");
return;
}

plist->current = plist->current->next;
printf("HOPPED O N -> : %s - %s\n", plist->current->song.title, plist->current->song.artist);
}

void previousSong(Playlist* plist) {
if (plist->current == NULL) {
printf("NO CUR R ENT SON G\n");
return;
}

if (plist->current->prev == NULL) {
printf("L ETS  BEGG IN\n");
return;
}

plist->current = plist->current->prev;
printf("<- PREV: %s - %s\n", plist->current->song.title, plist->current->song.artist);
}

void goTo(Playlist* plist, int position) {
if (position < 1 || position > plist->size) {
printf("WR ONG  PL  A CE\n");
return;
    }

Node* temp = plist->head;
for (int i = 1; i < position; i++) {
temp = temp->next;
}

plist->current = temp;
printf(">> JUMP  TO: %s - %s\n", plist->current->song.title, plist->current->song.artist);
}



//������ ����������� ���� ����������
void aboutShuffle(Playlist* plist) {
plist->shuffleMode=!plist->shuffleMode;
if  (plist->shuffleMode){
    printf("SHU FF LIN   ON\n");

} else {

printf("SHUF  FLIN  OFF\n");
}
}
void playRandom(Playlist* plist, HistoryStack* hs){
if (plist->head ==NULL){

    printf("PLA Y LIST   E M PTY\n");
    return;
}
int randomPos= (rand()%plist->size)+1; //� ���� ���
Node* temp= plist->head; //�������� ��� ���� ����
for(int i=1; i<randomPos;i++){

    temp = temp->next;
}
plist->current= temp;

play(plist,hs);
printf("[SHU F FLIN    IN  %d/%d]\n",randomPos, plist->size);
}
//����� ������������
void nextShuffle(Playlist* plist, HistoryStack* hs){
if(plist->shuffleMode){
    playRandom(plist, hs);

}else {
nextSong(plist);
}
}





void displayPlaylist(Playlist* plist) {
if (plist->head == NULL) {
printf("\nX WE  E MP PTY\n\n");
return;
    }

printf("\nP L AY LI S T\n");
Node* temp = plist->head;
int i = 1;
int totalDuration = 0;

while (temp != NULL) {
char marker = (temp == plist->current) ? '>' : ' ';
printf("%c %d. %s - %s [%d:%02d]\n",
marker, i,
temp->song.title,
temp->song.artist,
temp->song.duration / 60,
temp->song.duration % 60);
totalDuration += temp->song.duration;
temp = temp->next;
i++;
}

printf("********************\n");
printf("TO T A L: %d SO  NG S - DUR A TION: %d:%02d\n\n",
plist->size, totalDuration / 60, totalDuration % 60);
}

void displayCurrent(Playlist* plist) {
if (plist->current == NULL) {
printf("\nZZE R  O CU R R ENT SONGS\n\n");
return;
}

printf("\n>> CURRENT SO N G: %s - %s [%d:%02d]\n\n",
plist->current->song.title,
plist->current->song.artist,
plist->current->song.duration / 60,
plist->current->song.duration % 60);
}

Node* searchByTitle(Playlist* plist, char* title) {
Node* temp = plist->head;

while (temp != NULL) {
if (strcasecmp(temp->song.title, title) == 0) {
return temp;
}
temp = temp->next;
}

return NULL;
}

void searchByArtist(Playlist* plist, char* artist) {
Node* temp = plist->head;
int found = 0;

printf("\nSO N G S by %s:\n", artist);
printf("*******************\n");

while (temp != NULL) {
if (strcasecmp(temp->song.artist, artist) == 0) {
printf("* %s [%d:%02d]\n",
temp->song.title,
temp->song.duration / 60,
temp->song.duration % 60);
found = 1;
}
temp = temp->next;
}

if (!found) {
printf("ZER O  S O N G S\n");
}
printf("\n");
}



void pushHistory(HistoryStack* hs, Song song) { //�� ��������:
if (hs->top == HISTORY_SIZE - 1) {
        // ������ ������ - ���������� ���� ���� �� ����
for (int i = 0; i < HISTORY_SIZE - 1; i++) {
hs->songs[i] = hs->songs[i + 1];
}
hs->songs[HISTORY_SIZE - 1] = song;
} else {
hs->top++;
hs->songs[hs->top] = song;
}
}

void displayHistory(HistoryStack* hs) {
if (hs->top == -1) {
printf("\nSHE  E M P TY\n\n");
return;
}

printf("\n H I S T O RY \n");
for (int i = hs->top; i >= 0; i--) {
printf("%d. %s - %s\n",
hs->top - i + 1,
hs->songs[i].title,
hs->songs[i].artist);
}
printf("**************\n\n");
}

void goBack(Playlist* plist, HistoryStack* hs) {
if (hs->top <= 0) {
printf("HI S T O RY IS ON A BRE A K\n");
return;
}

displayHistory(hs);

printf("S E LEC T (1-%d): ", hs->top + 1);
int choice;
scanf("%d", &choice);

if (choice < 1 || choice > hs->top + 1) {
printf("WR O N G\n");
return;
}

int index = hs->top - choice + 1;
Song selectedSong = hs->songs[index];

    //SeaRCH
Node* found = searchByTitle(plist, selectedSong.title);
if (found) {
plist->current = found;
printf(">> BACK TO BACK: %s - %s\n", found->song.title, found->song.artist);

//Remove newer entries from history
hs->top = index - 1;
} else {
printf("NOT  FO UN D\n");
}
}

void clearHistory(HistoryStack* hs) {
hs->top = -1;
printf("+ C L E ANED \n");
}


//statistics �����������
void displayPopularSong(Playlist* plist) { //
if (plist->head == NULL) {
printf("SHE EM PTY\n");
return;
}

int maxPlays = 0;
Node* temp = plist->head;

while (temp != NULL) {
if (temp->song.playCount > maxPlays) {
maxPlays = temp->song.playCount;
}
temp = temp->next;
}

if (maxPlays == 0) {
printf("\nZE R  O  S O NG S  PLAYED \n\n");
return;
}

printf("\n* POP PU LAR (PLAYZ: %d):\n", maxPlays);
printf("*********************\n");

temp = plist->head;
while (temp != NULL) {
if (temp->song.playCount == maxPlays) {
printf("* %s - %s\n", temp->song.title, temp->song.artist);
}
temp = temp->next;
}
printf("\n");
}

double getTotalDuration(Playlist* plist) {
int total = 0;
Node* temp = plist->head;

while (temp != NULL) {
total += temp->song.duration;
temp = temp->next;
}

return total / 60.0;
}



void loadSongsFromFile(Playlist* plist, char* filename) {
FILE* file = fopen(filename, "r");
if (!file) {
printf("CAN  NOT  OP EN  FIL E: %s\n", filename);
return;
}


while (plist->head != NULL) {
Node* temp = plist->head;
plist->head = plist->head->next;
free(temp);
}
plist->tail = NULL;
plist->current = NULL;
plist->size = 0;

Song song;
while (fscanf(file, "%d,%99[^,],%99[^,],%d\n",
&song.id, song.title, song.artist, &song.duration) == 4) {
song.playCount = 0;
addSong(plist, song);
}

fclose(file);
printf("+ Lo a de d %d songs from %s\n", plist->size, filename);
}

void saveToFile(Playlist* plist, char* filename) {
FILE* file = fopen(filename, "w");
if (!file) {
printf("CAN NOT  CRE A TE FILE: %s\n", filename);
return;
}

Node* temp = plist->head;
while (temp != NULL) {
fprintf(file, "%d,%s,%s,%d\n",
temp->song.id,
temp->song.title,
temp->song.artist,
temp->song.duration);
temp = temp->next;
}

fclose(file);
printf("+++ %d SO NG S   T O %s\n", plist->size, filename);
}



void displayMenu() {
printf("**********************\n");

printf("  CICADA P L A EY R          \n");
printf("**********************\n");
printf(" 1.  Play                              \n");
printf(" 2.  Next                              \n");
printf(" 3.  Previous                          \n");
printf(" 4.  Back (History)                    \n");
printf(" 5.  Pick Song Position                \n");
printf(" 6.  Display Playlist                  \n");
printf(" 7.  Add Song                          \n");
printf(" 8.  Remove Song                       \n");
printf(" 9.  Search                            \n");
printf(" 10. History                           \n");
printf(" 11. Clear History                     \n");
printf(" 12. Statistics                        \n");
printf(" 13. Load from File                    \n");
printf(" 14. Save to File                      \n");
printf(" 15. Activate/De Shuffle               \n");
printf(" 16. Play One Random Song              \n");
printf(" 0.  Exit                              \n");
printf("***********************\n");
printf("YOU'VE PICKED: ");
}

void searchMenu(Playlist* plist) {
int choice;
char input[MAX_TITLE];
Node* found;


printf(" S E A R CH           \n");
printf("***************\n");
printf(" 1. By Title           \n");
printf(" 2. By Artist          \n");
printf(" 0. Back               \n");
printf("***************\n");
printf("YOU'VE PICKED: ");
scanf("%d", &choice);
getchar();

switch(choice) {
case 1:



printf("TI T LE: ");
fgets(input, MAX_TITLE, stdin);
input[strcspn(input, "\n")] = 0;
found = searchByTitle(plist, input);
if (found) {
printf("\n+ FO U ND: %s - %s [%d:%02d]\n\n",
found->song.title, found->song.artist,
found->song.duration / 60, found->song.duration % 60);
} else {
printf("\nNOT F O UN D\n\n");
}
break;

case 2:
printf("ART IST: ");
fgets(input, MAX_ARTIST, stdin);
input[strcspn(input, "\n")] = 0;
searchByArtist(plist, input);
break;
}
}


void statsMenu(Playlist* plist) {
int choice;


printf(" S T A TI ST I C S        \n");
printf("*****************\n");
printf(" 1. Most Popular       \n");
printf(" 2. Total Duration     \n");
printf(" 0. Back               \n");
printf("========================\n");
printf("YOU'VE PICKED: ");
scanf("%d", &choice);

switch(choice) {
case 1:
displayPopularSong(plist);
break;
case 2:
printf("\nTO T AL: %.2f minutes\n\n", getTotalDuration(plist));
break;
}
}

int main() {
Playlist* plist = createPlaylist();
HistoryStack hs;
hs.top = -1;

int choice, position;
Song song;
char filename[100];


Song s1 = {1, "Jeux d'eau", "Martha Argerich", 390, 0};
Song s2 = {2, "Topknot", "Cornershop", 183, 0};
Song s3 = {3, "Your Love is My Drug", "Kesha", 354, 0};
Song s4 = {4, "La Perla", "Rosalia", 482, 0};
Song s5 = {5, "B2B", "Charli xcx", 431, 0};

addSong(plist, s1);
addSong(plist, s2);
addSong(plist, s3);
addSong(plist, s4);
addSong(plist, s5);

while (1) {
displayMenu();
scanf("%d", &choice);
getchar();

switch(choice) {
case 1:
play(plist, &hs);
break;
case 2:
nextShuffle(plist, &hs);
break;
case 3:
previousSong(plist);
break;
case 4:
goBack(plist, &hs);
break;
case 5:
printf("PICK SON G  PO SI TION (1-%d): ", plist->size);
scanf("%d", &position);
goTo(plist, position);
break;
case 6:
displayPlaylist(plist);
break;
case 7:
printf("\nSONGS NUMBER PLACE (e.g 6): ");
scanf("%d", &song.id);
getchar();
printf("TI TLE: ");
fgets(song.title, MAX_TITLE, stdin);
song.title[strcspn(song.title, "\n")] = 0;
printf("AR T I ST: ");
fgets(song.artist, MAX_ARTIST, stdin);
song.artist[strcspn(song.artist, "\n")] = 0;
printf("DU R A T ION (sec): ");
scanf("%d", &song.duration);
song.playCount = 0;
addSong(plist, song);
break;
case 8:
printf("PO SITION TO  RE  M O VE (1-%d): ", plist->size);
scanf("%d", &position);
removeAt(plist, position);
break;
case 9:
searchMenu(plist);
break;
case 10:
displayHistory(&hs);
break;
case 11:
clearHistory(&hs);
break;
case 12:
statsMenu(plist);
break;
case 13:
printf("FILE NA M E: (preloaded default file -song.txt) ");
scanf("%s", filename);
loadSongsFromFile(plist, filename);
break;
case 14:
printf("FI LE  NAM E: ");
scanf("%s", filename);
saveToFile(plist, filename);
break;
case 15:
aboutShuffle(plist);
break;
case 16:
playRandom(plist,&hs);
break;
case 0:
printf("\nCHAO\n\n");
return 0;
default:
printf("E R RO R!\n");
}
}

return 0;}
